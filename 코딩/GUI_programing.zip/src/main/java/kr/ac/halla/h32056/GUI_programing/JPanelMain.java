package kr.ac.halla.h32056.GUI_programing;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

@SuppressWarnings("serial")
class JPanelMain extends JPanel{
	private JButton start,book,rule,option,END;
	private JPanelTop win;
	private ImageIcon image = new ImageIcon("D:\\TP\\ETC\\배경첫화면.png");
	private Image imagescale = image.getImage().getScaledInstance(1920,1040, Image.SCALE_DEFAULT);
	private ImageIcon image2 = new ImageIcon(imagescale);
	private ImageIcon startBimage = new ImageIcon("D:\\TP\\ETC\\start.png");
	private ImageIcon boardBimage = new ImageIcon("D:\\TP\\ETC\\board.png");
	private ImageIcon ruleBimage = new ImageIcon("D:\\TP\\ETC\\rule.png");
	private ImageIcon optionBimage = new ImageIcon("D:\\TP\\ETC\\option.png");
	private ImageIcon endBimage = new ImageIcon("D:\\TP\\ETC\\end.png");
	public void paintComponent(Graphics g) {
			g.drawImage(image2.getImage(), 0,0,null);
			setOpaque(false);
			super.paintComponent(g);
		}
	public JPanelMain(JPanelTop win) {
		this.win=win;
		setLayout(null);
		start = new JButton(startBimage);
		start.setSize(250,80);
		start.setLocation(200,350);
		start.setBorderPainted(false);
		start.setFocusPainted(false);
		start.setContentAreaFilled(false);
		book = new JButton(boardBimage);
		book.setSize(250,80);
		book.setLocation(200,470);
		book.addActionListener(new book());
		book.setBorderPainted(false);
		book.setFocusPainted(false);
		book.setContentAreaFilled(false);
		rule = new JButton(ruleBimage);
		rule.setSize(250,80);
		rule.setLocation(200,590);
		rule.addActionListener(new rule());
		rule.setBorderPainted(false);
		rule.setFocusPainted(false);
		rule.setContentAreaFilled(false);
		option = new JButton(optionBimage);
		option.setSize(250,80);
		option.setLocation(200,720);
		option.addActionListener(new option());
		option.setBorderPainted(false);
		option.setFocusPainted(false);
		option.setContentAreaFilled(false);
		END = new JButton(endBimage);
		END.setSize(250,80);
		END.setLocation(200,840);
		END.addActionListener(new Close());
		END.setBorderPainted(false);
		END.setFocusPainted(false);
		END.setContentAreaFilled(false);
		
		add(start);
		add(book);
		add(rule);
		add(option);
		add(END);
		start.addActionListener(new start());
	}
	class start implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			win.change("start");
		}
	}
	class book implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			win.change("book");
		}
	}
	class rule implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			win.change("rule");
		}
	}class option implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			win.change("option");
		}
	}
	class Close implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	}
}